# Covid-19 Landing Page

Covid-19 Landing Page

## Tools & Languages

- HTML
- CSS
- JavaScript
